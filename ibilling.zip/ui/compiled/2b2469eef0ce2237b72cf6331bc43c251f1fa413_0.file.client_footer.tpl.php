<?php
/* Smarty version 3.1.39, created on 2021-03-02 16:41:33
  from '/Users/razib/Documents/valet/ibc/ibilling/ui/theme/ibilling/sections/client_footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_603eb10d9ccd69_32823691',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2b2469eef0ce2237b72cf6331bc43c251f1fa413' => 
    array (
      0 => '/Users/razib/Documents/valet/ibc/ibilling/ui/theme/ibilling/sections/client_footer.tpl',
      1 => 1557906298,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_603eb10d9ccd69_32823691 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender(((string)$_smarty_tpl->tpl_vars['client_tplfooter']->value).".tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, true);
}
}

<?php
header('location: ../?ng=client/where/');

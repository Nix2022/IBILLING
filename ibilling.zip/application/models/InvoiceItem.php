<?php
use Illuminate\Database\Eloquent\Model;

class InvoiceItem extends Model
{
    protected $table = 'sys_invoiceitems';
}
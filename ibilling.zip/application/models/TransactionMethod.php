<?php
use Illuminate\Database\Eloquent\Model;

class TransactionMethod extends Model
{
    protected $table = 'sys_pmethods';



}
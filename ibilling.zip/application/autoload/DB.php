<?php
Class DB extends Illuminate\Database\Capsule\Manager{

}